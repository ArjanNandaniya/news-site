<?php
require 'src/Suggestotron/Autoloader.php';
require 'src/Suggestotron/TopicData.php';
require 'src/Suggestotron/Template.php';

require_once 'src/Suggestotron/Config.php';
\Suggestotron\Config::setDirectory('config');

$config = \Suggestotron\Config::get('autoload');
require_once $config['class_path'] . '/Suggestotron/Autoloader.php';

foreach ($topics as $topic) {
	echo "<h3>" . $topic['title'] . " (ID: " . $topic['id'] . ")</h3>";
	echo "<p>";
	echo nl2br($topic['description']);
	echo "</p>";
	echo "<p>";
	echo "<a href='/edit.php?id=" . $topic['id'] . "'>Edit</a>";
	echo " | ";
	echo "<a href='/delete.php?id=" . $topic['id'] . "'>Delete</a>";
	echo "</p>";
}
?>
<?php
require_once 'src/Suggestotron/TopicData.php';

if (!isset($_GET['id']) || empty($_GET['id'])) {
	echo "You did not pass in an ID.";
	exit;
}

$data = new \Suggestotron\TopicData();
$topic = $data->getTopic($_GET['id']);

if ($topic === false) {
	echo "Topic not found!";
	exit;
}

if ($data->delete($_GET['id'])) {
	header("Location: /index.php");
	exit;
} else {
	echo "An error occurred";
}
?>