<?php
return [
	'class_path' => realpath('src'),
];
?>