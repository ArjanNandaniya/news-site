<?php
return [
	"username" => "root",
	"password" => "sphere",
	"hostname" => "localhost",
	"dbname" => "suggestotron",
];
?>